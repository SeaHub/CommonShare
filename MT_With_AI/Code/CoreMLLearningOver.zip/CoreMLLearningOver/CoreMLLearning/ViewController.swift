//
//  ViewController.swift
//  CoreMLLearning
//
//  Created by SeaHub on 2017/7/8.
//  Copyright © 2017年 SeaCluster. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController {
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension ViewController {
    fileprivate func predictPhoto() {
        self.resultLabel.text = "Predicting..."
        
        guard let model = try? VNCoreMLModel(for: GoogLeNetPlaces().model) else {
            fatalError("can't load model")
        }
        
        let request = VNCoreMLRequest(model: model) { [unowned self] request, error in
            guard let results = request.results as? [VNClassificationObservation],
                let topResult = results.first else {
                    fatalError("unexpected result type from VNCoreMLRequest")
            }
            
            DispatchQueue.main.async {
                debugPrint(topResult)
                self.resultLabel.text = "\(Int(topResult.confidence * 100))% \(topResult.identifier)"
            }
        }
        
        guard let image = self.photoImageView.image,
            let ciImage = CIImage(image: image) else {
            fatalError("couldn't convert UIImage to CIImage")
        }
        
        let handler = VNImageRequestHandler(ciImage: ciImage)
        DispatchQueue.global(qos: .userInteractive).async {
            do {
                try handler.perform([request])
            } catch {
                print(error)
            }
        }
    }
}

extension ViewController {
    @IBAction func chooseImageClicked(_ sender: Any) {
        let pickerController        = UIImagePickerController()
        pickerController.delegate   = self
        pickerController.sourceType = .savedPhotosAlbum
        self.present(pickerController, animated: true)
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]) {
        dismiss(animated: true)
        
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("couldn't load image from Photos")
        }
        
        self.photoImageView.image = image
        self.predictPhoto()
    }
}

